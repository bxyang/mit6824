import tensorflow as tf
import numpy as np
import pytest

from .Model import memory_augmented_neural_network

